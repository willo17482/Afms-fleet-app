===============================
AFMS Windows Installer Builder
===============================

REQUIREMENTS:
1. Windows PC
2. Python installed + PyInstaller build already complete
3. NSIS installed (https://nsis.sourceforge.io/Download)

STEPS TO BUILD INSTALLER:
1. Run the PyInstaller build:
   > pyinstaller afms.spec

2. Locate the EXE in:
   dist\AFMS_Desktop\AFMS_Desktop.exe

3. Download and install NSIS.

4. Open NSIS, click "Compile NSI script", and select:
   AFMS_Installer.nsi

5. NSIS will produce:
   AFMS_Installer.exe (your distributable setup file)

===============================